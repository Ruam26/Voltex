package Ventanas;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class SesionUsuario {

    private static SesionUsuario instancia;
    private String usuario;
    private String nombreUsuario;
    private String estratoUsuario;

    private SesionUsuario() {}

    public static SesionUsuario getInstancia() {
        if (instancia == null) {
            instancia = new SesionUsuario();
        }
        return instancia;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }

    public String getEstratoUsuario() {
        return estratoUsuario;
    }

    public void setEstratoUsuario(String estratoUsuario) {
        this.estratoUsuario = estratoUsuario;
    }

    public void buscarDatosUsuario(String usuario, Connection conexion) {
        String query = "SELECT Nombre, Estrato FROM clientes WHERE Usuario = ?";
        try (PreparedStatement pstmt = conexion.prepareStatement(query)) {
            pstmt.setString(1, usuario);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                this.nombreUsuario = rs.getString("Nombre");
                this.estratoUsuario = rs.getString("Estrato");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    
}
