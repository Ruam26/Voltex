
package Pruebas;

import java.sql.*;
import com.mysql.cj.xdevapi.Session;
import com.mysql.cj.xdevapi.SessionFactory;
import com.mysql.cj.xdevapi.Statement;
public class ConexionBD {
    Connection cn;
    
    public Connection Conexion() {
      try{
        Class. forName("com.mysql.cj.jdbc.Driver");
        cn = DriverManager.getConnection("jdbc:mysql://localhost/electrodomesticos", "root","");
        System.out.println("Se conecto Exitosamente"); 
      }catch(Exception e){
          System.out.println(e.getMessage());
      }return cn;
     }
    
    Statement CreateStatement(){
        throw new UnsupportedOperationException("No soportable");
    }
    
}
